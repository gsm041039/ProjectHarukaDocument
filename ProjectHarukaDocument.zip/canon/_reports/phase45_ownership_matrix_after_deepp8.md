﻿# Phase45 DeepP8 Ownership Matrix (After Cleanup)

## Summary
- TOTAL=8
- HIGH=0
- MEDIUM=0
- LOW=8

## Risk Tags
| Tag | Count |
|---|---:|
| decision_ref | 8 |

## Top Rows (up to 20)
| File | Para | Owner | Score | Tags | Snippet |
|---|---:|---|---:|---|---|
| canon/02_glossary.md | 83 | glossary | 1 | decision_ref | **See also**: [World Rules](01_world_rules_and_costs.md#rule-magic-cost) \\| [Trinity Spectrum](#term-trinity-spectrum) \\| [Decision Log](99_decision_log.md#decision-cf001) |
| canon/01_world_rules_and_costs.md | 67 | rule | 1 | decision_ref | **關鍵事件摘要**（事件年份與順序見 [Timeline](04_timeline_canon.md#event-alpha-divergence)；口徑見 [Decision Log CF-002](99_decision_log.md#decision-cf002)）： - 幼年晴香目睹黑奏攻擊家園 - 母親花子和姊姊美夜子同時在她面前被殺 - 晴香的「潛力之種」被極端創傷激活，向[集體潛意識](02_glossary.md#te |
| canon/04_timeline_canon.md | 73 | timeline | 1 | decision_ref | **統計**： - 涵蓋帝國歷 0-114 年 - 關鍵事件節點：80+ - Alpha/Beta 分歧點：**帝國歷 102 年**（見 [CF-002](99_decision_log.md#decision-cf002)） - 故事主線：帝國歷 113-114 年（約 21 個月） |
| canon/04_timeline_canon.md | 15 | timeline | 1 | decision_ref | > **世界分裂為 [Alpha](02_glossary.md#term-alpha-line)/[Beta](02_glossary.md#term-beta-line) 兩條時間線的關鍵時刻。** > 關於 102 年的裁決，見 [Decision Log CF-002](99_decision_log.md#decision-cf002)。 |
| canon/01_world_rules_and_costs.md | 44 | rule | 1 | decision_ref | <a id="rule-physiological-rejection"></a> #### 生理排斥法則（Physiological Rejection） - **定義**：靈魂與肉身對外來高能情緒流的防禦性排斥，常呈現「先狂喜、後反噬」。 - **觸發條件**：高強度調律、反覆超限變身、長時間停留情緒污染區。 - **代價**：[靈魂延遲](02_glossary.md#term-soul-lag)、嘔吐、感官錯位、短暫解離。 -  |
| canon/01_world_rules_and_costs.md | 40 | rule | 1 | decision_ref | > 統一口徑：情感耗損為主體機制，代謝反應為生理副作用。見 [Decision Log CF-001](99_decision_log.md#decision-cf001)。 |
| canon/01_world_rules_and_costs.md | 55 | rule | 1 | decision_ref | > 統一口徑：見 [Decision Log CF-004a](99_decision_log.md#decision-cf004a) |
| canon/01_world_rules_and_costs.md | 53 | rule | 1 | decision_ref | > 見 [Decision Log CF-004c](99_decision_log.md#decision-cf004c) |
